RCOMP 2020-2021 Project - Sprint 2 review
=========================================
### Sprint master: 1191430 ###

# 1. Sprint's backlog #
|Task|Task Description|
|---------|-----------|
|T.2.1    |Development of a layer two and layer three Packet Tracer simulation for building 1, and also encompassing the campus backbone.Integration of every members’ Packet Tracer simulations into a single simulation.|
|T.2.2    |Development of a layer two and layer three Packet Tracer simulation for building 2, and also encompassing the campus backbone.|
|T.2.3    |Development of a layer two and layer three Packet Tracer simulation for building 3, and also encompassing the campus backbone.|
|T.2.5    |Development of a layer two and layer three Packet Tracer simulation for building 5, and also encompassing the campus backbone.|

# 2. Subtasks assessment #

## T.2.1. - 1191507 ##

### Totally implemented with no issues. ###

Obs.: The routing of the ISP could be improved since any PING to an outside IP address will fail. In the next sprint, an alternative will be studied.

## T.2.2. - 1191430 ##

### Totally implemented with issues. ###

## T.2.3. - 1190693 ##

### Totally implemented with no issues. ###

## T.2.4. - 1181490 ##

### Totally implemented with issues. ###
